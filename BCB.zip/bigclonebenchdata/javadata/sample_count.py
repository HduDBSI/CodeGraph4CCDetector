


file = open("./DataSetJsonVec/BCB/javadata/test.txt", 'r')
lines = file.readlines()
file.close()

pos = 0
neg = 0
datalist = []

for line in lines:
    datalist.append(line.split()[0])
    datalist.append(line.split()[1])
    if int(line.split()[-1]) == 1:
        pos += 1
    elif int(line.split()[-1]) == 0:
        neg += 1

print("正样本 ", pos, "负样本 ", neg, "正/负 ", pos*1.0/neg)
print("datalist ",len(datalist)," set datalist",len(set(datalist)))
'''
GCJ
trainall   正样本  144258 负样本  582118 正/负  0.24781573495408146
train11    正样本  176699 负样本  176699 正/负  1.0
trainmid   正样本  9829 负样本  40171 正/负  0.24467899728659978
trainneg   正样本  0 负样本  711760 
trainpos   正样本  176018 负样本  0 
trainsmall 正样本  988 负样本  4012 正/负  0.24626121635094717
valid      正样本  2721 负样本  10974 正/负  0.24794969928922908
test       正样本  2676 负样本  11019 正/负  0.2428532534712769


BCB
traindata      正样本  225431 负样本  1358499 正/负  0.1659412336703965
traindata11    正样本  225431 负样本  225431 正/负  1.0
traindata11big 正样本  450862 负样本  450862 正/负  1.0
devdata        正样本  53962 负样本  362366 正/负  0.14891573712765546
testdata       正样本  57105 负样本  359223 正/负  0.15896810616246732
'''